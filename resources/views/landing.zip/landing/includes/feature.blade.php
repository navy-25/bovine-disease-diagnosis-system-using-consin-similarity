<section class="gray-bg section-padding" id="service-page">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-4">
                    <div class="box">
                        <div class="box-icon">
                            <img src="images-landing/service-icon-2.png" alt="">
                        </div>
                        <h4>Simple</h4>
                        <p>Tampilan interface & menu didesain sesimple mungkin agar mudah digunakan.</p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4">
                    <div class="box">
                        <div class="box-icon">
                            <img src="images-landing/portfolio-icon-6.png" alt="">
                        </div>
                        <h4>Flexibel</h4>
                        <p>siPicow bisa diakses melalui website dan aplikasi android smartphone.</p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4">
                    <div class="box">
                        <div class="box-icon">
                            <img src="images-landing/portfolio-icon-4.png" alt="">
                        </div>
                        <h4>Useful</h4>
                        <p>Menambah wawasan, pengetahuan dan keilmuwan dibidang peternakan. Khususnya pada hewan Sapi.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>