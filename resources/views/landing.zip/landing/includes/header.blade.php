 <header class="header-area overlay full-height relative v-center" id="home-page">
        <div class="absolute anlge-bg"></div>
        <div class="container">
            <div class="row v-center">
                <div class="col-xs-12 col-md-7 header-text">
                    <h2>Jadilah Peternak yang Cerdas, Kompeten & Tanggap</h2>
                    <p>Beternak adalah belajar tentang Kesabaran, Kamu tidak bisa meminta tanaman untuk bergegas atau menciptakan seekor Anak Sapi dalam dua hari. Oleh karena itu Sipicow hadir dalam wujud aplikasi Smartphone agar dapat memberikan informasi berupa tata cara dan teknik dalam beternak sapi yang baik melalui sistem pakar.</p>
                    <a href="/masuk" class="button white"><b>Coba Sekarang</b></a>
                    <p style="margin-top:20px">Belum punya akun ? Daftar aja <a href="/daftar" style="color:orange">disini !</a></p>
                </div>
                <div class="hidden-xs hidden-sm col-md-5 text-right">
                    <div class="screen-box screen-slider">
                        <div class="item">
                            <img src="images-landing/screen-1.png" alt="">
                        </div>
                        <div class="item">
                            <img src="images-landing/screen-2.png" alt="">
                        </div>
                        <div class="item">
                            <img src="images-landing/screen-3.png" alt="">
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
    </header>